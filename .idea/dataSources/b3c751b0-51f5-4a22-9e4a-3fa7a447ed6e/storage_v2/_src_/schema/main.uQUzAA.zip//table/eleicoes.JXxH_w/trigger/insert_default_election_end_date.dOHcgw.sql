CREATE TRIGGER insert_default_election_end_date
  AFTER INSERT
  ON eleicoes
  FOR EACH ROW
  WHEN (NEW.fim IS 'YYYY-MM-DD HH:MM:SS')
BEGIN
  UPDATE eleicoes
  SET fim = datetime('now', '+3 days')
  WHERE fim = 'YYYY-MM-DD HH:MM:SS';
END;

