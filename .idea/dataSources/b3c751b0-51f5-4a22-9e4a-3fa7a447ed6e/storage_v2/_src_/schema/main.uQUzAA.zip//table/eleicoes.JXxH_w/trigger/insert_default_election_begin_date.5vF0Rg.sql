CREATE TRIGGER insert_default_election_begin_date
  AFTER INSERT
  ON eleicoes
  FOR EACH ROW
  WHEN (NEW.inicio IS 'YYYY-MM-DD HH:MM:SS')
BEGIN
  UPDATE eleicoes
  SET inicio = datetime('now')
  WHERE inicio = 'YYYY-MM-DD HH:MM:SS';
END;

