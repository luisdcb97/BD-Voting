CREATE TRIGGER check_types_on_update_membros_listas
  BEFORE UPDATE
  ON membros_listas
  FOR EACH ROW
  WHEN (SELECT funcao FROM pessoas WHERE id = NEW.id_pessoa)
       !=
       (SELECT tipo FROM listas WHERE id = NEW.id_lista)
BEGIN
  SELECT RAISE(FAIL, 'Person has to have same function as list');
END;

