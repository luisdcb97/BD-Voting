CREATE TRIGGER validate_datespan
  BEFORE INSERT
  ON eleicoes
  FOR EACH ROW
  WHEN (new.inicio > new.fim)
BEGIN
  SELECT raise(FAIL, 'End of election has to be after beginning');
END;

